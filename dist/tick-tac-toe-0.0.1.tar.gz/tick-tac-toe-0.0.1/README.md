# Ticktacktoe

Classical ticktacktoe game in cli. Allows to play with two players only.

## User Manual
- run the program.
- google ticktacktoe game rules if you are noob
- valid input keys are 1,2,3,...,9

## Things to be improved

- [ ] make dumb bot to allow single player game
- [ ] make the main logic more efficient
 